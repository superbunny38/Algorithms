import time
def countdown(n):
    print("countdown({})".format(n))
    if n>0:
        print("print({})".format(n))
        print("time.sleep(1)")#1초 동안 쉼
        countdown(n-1)
    else:
        print("Go !")


#countdown(5)


def sigma(n):
    print("sigma({})".format(n))
    if n>0:
        print("return {}+sigma({}): {}".format(n,n-1,n+sigma(n-1)))
        return n+sigma(n-1)
    else:
        print("return 0")
        return 0

print(sigma(3))


