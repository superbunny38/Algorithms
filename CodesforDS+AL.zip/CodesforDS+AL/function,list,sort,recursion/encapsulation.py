def sigma1(n):
    def loop(n, summation):
        if n>0:
            return loop(n-1, n+summation)
        else:
            return summation
    return loop(n,0)


print(sigma1(5))
