#tail recursion

def loop(n, summation):
    if n>0:
        return loop(n-1, n+summation)
    else:
        return summation

def sigma1(n):
    return loop(n,0)


print(sigma1(5))


