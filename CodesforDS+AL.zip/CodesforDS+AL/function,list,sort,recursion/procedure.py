
def procedure():
    print("Hello, I return nothing")

a = procedure()
print("returned:",a)



