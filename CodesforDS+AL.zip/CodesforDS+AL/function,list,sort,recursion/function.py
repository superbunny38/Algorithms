def function(param1, param2):
    print("hello")
    return param1 + param2



