#dist[i][j]: i에서 j로 가는 경우 최단 경로의 값들
import sys
INF = sys.maxsize

def Floyd_Warshall(a):
    dist = [[INF]*n for i in range(n)]#최단 경로 담는 배열

    for i in range(n):#최단 경로 담는 배열 초기화
        for j in range(n):
            dist[i][j] = a[i][j]

    for k in range(n):#거치는 점
        for i in range(n):#시작점
            for j in range(n):#끝점
                #k를 거쳤을 때의 경로가 더 적은 경로
                if dist[i][j] > dist[i][k] + dist[k][j]:
                    dist[i][j] = dist[i][k]+dist[k][j]
    return dist

def display(n,dist):
    for i in range(n):
        for j in range(n):
            print(dist[i][j],end =" ")
        print()


    

n = 4#정점 수
a = [[0,2,INF,4],[2,0,INF,5],[3,INF,0,INF],[INF,2,1,0]]
dist = Floyd_Warshall(a)
display(n,dist)
print()
n = 3
b = [[0,1,43],[1,0,6],[INF,INF,0]]
dist = Floyd_Warshall(b)
display(n,dist)
print()
n = 2
c = [[0,25],[INF,0]]
dist = Floyd_Warshall(c)
display(n,dist)
