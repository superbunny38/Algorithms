'''
1번 컴퓨터가 웜 바이러스에 걸렸다.
컴퓨터의 수와 네트워크 상에서 서로 연결되어 있는 정보가 주어질 때,
1번 컴퓨터를 통해 웜 바이러스에 걸리게 되는
컴퓨터의 수를 출력하는 프로그램을 작성하시오.
'''
def dfs(node):
    if check[node] == 0:
        check[node] = 1
        for t in graph[node]:
            dfs(t)

N = int(input())
graph = [[] for _ in range(N+1)]
for _ in range(int(input())):
    a, b = map(int, input().split())
    graph[a].append(b)
    graph[b].append(a)
check = [0]*(N+1)
dfs(1)
print(sum(check)-1)


from collections import deque

def bfs(node):
    queue = deque()
    queue.append(node)
    while queue:
        node = queue.popleft()
        if check[node] == 0:
            check[node] = 1
            for t in graph[node]:
                queue.append(t)

N = int(input())
graph = [[] for _ in range(N+1)]
for _ in range(int(input())):
    a, b = map(int, input().split())
    graph[a].append(b)
    graph[b].append(a)
check = [0]*(N+1)
bfs(1)
print(sum(check)-1)
