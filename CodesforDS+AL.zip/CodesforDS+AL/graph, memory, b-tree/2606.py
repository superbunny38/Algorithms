n = int(input())
m = int(input())
graph = [[]*n for _ in range(n+1)]
for _ in range(m):
    a,b = map(int,input().split())
    graph[a].append(b)
    graph[b].append(a)


for idx,li in enumerate(graph):
    print("{} is connected to {}".format(idx,li))
    
   
cnt = 0
visited = [0]*(n+1)
print(visited)

def dfs(start):
    global cnt
    visited[start] = 1
    for i in graph[start]:
        if visited[i]==0:
            dfs(i)
            cnt +=1
 
dfs(1)
print(cnt)
print(visited)
