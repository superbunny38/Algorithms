class Node(object):

    def __init__(self, name):
        ''' assumes name a string '''
        self.name = name

    def get_name(self):
        return self.name

    def __str__(self):
        return self.name

class Edge(object):

    def __init__(self, src, dest):
        '''assume src and dest are nodes '''
        self.src = src
        self.dest = dest

    def get_source(self):
        return self.src

    def get_destination(self):
        return self.dest

    def __str__(self):
        return self.src.get_name() + '-->' + \
            self.dest.get_name()


class Digraph(object):
    # node is a list of the nodes in the graph
    # edges is a dict mapping each node to 
    # a list of its children
    def __init__(self):
        self.nodes = []
        self.edges = {}

    def add_node(self, node):
        if node in self.nodes:
            raise ValueError('Duplicate Node')
        else:
            self.nodes.append(node)
            self.edges[node] = []

    def add_edge(self, edge):
        src = edge.get_source()
        dest = edge.get_destination()
        if not (src in self.nodes and dest in self.nodes):
            raise ValueError('Node not in graph')
        self.edges[src].append(dest)

    def children_of(self, node):
        return self.edges[node]

    def has_node(self, node):
        return node in self.nodes

    def __str__(self):
        result = ''
        for src in self.nodes:
            for dest in self.edges[src]:
                result = result + src.get_name() + \
                    '-->' + dest.get_name() + '\n'
        return result[:-1] # remove last newline

# driver code here
if __name__ == '__main__':
    # create the digraph
    digraph = Digraph()
    # create the nodes 
    node_a = Node('A')
    node_b = Node('B')
    node_c = Node('C')
    node_d = Node('D')
    node_e = Node ('E')
    # add the nodes to the digraph instance
    digraph.add_node(node_a)
    digraph.add_node(node_b)
    digraph.add_node(node_c)
    digraph.add_node(node_d)
    digraph.add_node(node_e)

    # Next create the edges 
    edge_ab = Edge(node_a, node_b)
    edge_ac = Edge(node_a, node_c)
    edge_bd = Edge(node_b, node_d)
    edge_cd = Edge(node_c, node_d)
    edge_ce = Edge(node_c, node_e)
    edge_de = Edge(node_d, node_e)    
    # then we add the directed edges
    digraph.add_edge(edge_ab)
    digraph.add_edge(edge_ac)
    digraph.add_edge(edge_bd)
    digraph.add_edge(edge_cd)
    digraph.add_edge(edge_ce)
    digraph.add_edge(edge_de)
    
    # everything's ready. 
    # Let's print it
    print('The complete digraph is:')
    print(digraph)
    print()
    print('The children of node C are:')
    for i in digraph.children_of(node_c):
        print(i)

