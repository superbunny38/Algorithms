import time
def run_algorithm():
    print("algorithm running...")
    time.sleep(3)

start_time= time.time()
run_algorithm()
end_time = time.time()
elapsed = end_time-start_time
print("elapsed:{}".format(elapsed))
