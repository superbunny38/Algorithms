

#examples of basic operations
x = 10
name = 'Andrew'
is_verified = True
