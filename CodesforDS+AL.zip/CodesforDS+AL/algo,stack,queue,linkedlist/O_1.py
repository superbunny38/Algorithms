if a > b:
    return True
else:
    return False


