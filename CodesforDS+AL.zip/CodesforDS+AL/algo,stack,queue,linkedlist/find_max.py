import time
def find_max(data):
    """Return the maximum element from a nonempty Python list."""
    biggest = data[0]#start searching from the front
    for val in data:
        if val>biggest:
            biggest = val
    return biggest


d = [1,2]
find_max(d)
data = [3,2,6,100,0]
s1 = time.time()
print(find_max(data))
e1 = time.time()
print("n: {} elapsed:{}".format(len(data),e1-s1))

data2 = [3,2,1,1,2,3,40,300,100,0,0,2,3,4,5]
s2 = time.time()
print(find_max(data2))
e2 = time.time()
print("n:{} elapsed:{}".format(len(data2),e2-s2))
