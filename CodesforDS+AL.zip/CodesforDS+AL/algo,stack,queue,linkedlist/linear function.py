
#linear function algorithm analysis
my_list = [1, 2, 3, 4, 5]
for i in my_list:
    print(i == 2)
