#counting word frequencies

freq = {}
for piece in open(filename).read().lower().split():
    word = "".join(c for c in piece if c.isalpha())
    if word:#require at least one alphabetic character
        freq[word] 1+ freq.get(word,0)

max_word = ""
max_count = 0
for (w,c) in frq.items():
    if c> max_count:
        max_word = w
        max_count = c

print("The most frequent word is", max_word)
print("Its number of occurences is", max_count)
