from TreeMap import *
class SplayTreeMap(TreeMap):
    """Sorted map implementation using a splay tree."""
    
