def find_brute(T,P):
    """Return the lowest index of T at which substring P begins ( or else -1). """
    n, m = len(T), len(P)#introduce convenient notations
        
    for i in range(n-m+1):
        k = 0#an index into pattern p
        while k < m and T[i+k] == P[k]:#kth character of P matches
            k += 1
        
        if k == m:
            return i
    return -1

T = "abacaabaccabacabaabb"

P = "abacab"

idx = find_brute(T,P)
print(idx)

print(T[idx:idx+len(P)])#P in T
