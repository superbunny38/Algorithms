class Node(object):
    def __init__(self, key, data=None):
        self.key = key
        self.data = data#문자열의 종료를 알리는 flag
        self.children = {}
        
class Trie:
    def __init__(self):
        self.head = Node(None)

    def insert(self, string):
        current_node = self.head

        for char in string:
            if char not in current_node.children:
                current_node.children[char] = Node(char)
            current_node = current_node.children[char]
        current_node.data = string

    def search(self, string):
        print("searching:",string, "->",end = " ")
        current_node = self.head

        for char in string:
            if char in current_node.children:
                current_node = current_node.children[char]
            else:
                return False

        if current_node.data:
            return True
        else:
            return False

    def starts_with(self, prefix):
        current_node = self.head
        words = []
        print("words starting with prefix <{}>:".format(prefix))
        for p in prefix:
            if p in current_node.children:
                current_node = current_node.children[p]
            else:
                return None

        current_node = [current_node]
        next_node = []
        while True:
            for node in current_node:
                if node.data:
                    words.append(node.data)
                next_node.extend(list(node.children.values()))
            if len(next_node) != 0:
                current_node = next_node
                next_node = []
            else:
                break
        
        return words


trie = Trie()
word_list = ["frodo", "front", "firefox", "fire"]
for word in word_list:
    trie.insert(word)#insert word in tree

print("-----search-------")
print(trie.search("friend"))
print(trie.search("frodo"))
print(trie.search("fire"))


print("\n-------start with prefix-----")
print(trie.starts_with("fire"))
print(trie.starts_with("fro"))
print(trie.starts_with("jimmy"))
print(trie.starts_with("f"))
