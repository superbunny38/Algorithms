#11053

def bigger_than_everything(possible_seq, maxi):
    count = 0
    n = len(possible_seq)
    for seq in possible_seq:
        if maxi > seq[-1]:
            count += 1
    if count == n:
        return True
    else:
        return False


def smaller_than_everything(possible_seq, mini):
    count = 0
    n = len(possible_seq)
    for seq in possible_seq:
        if mini < seq[0]:
            count += 1
    if n== count:
        return True
    else:
        return False

def process(possible_seq, cur):
    result = []
    
    for seq in possible_seq:
        found = False
        for idx in range(len(seq)-1):
            if seq[idx] <cur and cur < seq[idx+1]:
                new_seq = seq[:idx+1]
                new_seq.append(cur)
                result.append(seq)
                result.append(new_seq)
                found = True
                break
        if found == False:
            result.append(seq)
        
    return list(result)

def find_max_length(possible_seq):
    max_length =0
    for seq in possible_seq:
        if max_length < len(seq):
            max_length = len(seq)
    return max_length

def leave_maxi_length(possible_seq):
    max_length =0
    result = []
    max_length = find_max_length(possible_seq)
    #print("max_length",max_length)
    for seq in possible_seq:
        if len(seq) == max_length:
            result.append(seq)
    return result
            
def prune(possible_seq,cur):
    possible_seq = leave_maxi_length(possible_seq)
    for seq in possible_seq:
        if seq[-1]<cur:
            seq.append(cur)
    return possible_seq

def insert(possible_seq,cur):
    for seq in possible_seq:
        if seq[-1]<cur:
            seq.append(cur)
    return possible_seq

def display(possible_seq):
    print("possible sequence:")
    for seq in possible_seq:
        print(seq)
        
n = int(input())
list_numbers = input().split()
list_numbers = [int(x) for x in list_numbers]
prev = list_numbers[0]
possible_seq = [[prev]]
i = 1

while i < n:
    cur = list_numbers[i]
    cur_idx = i
    #print("prev:",prev,"cur:",cur)
    max_length = find_max_length(possible_seq)
    if prev>cur:
        if n-cur_idx-1<max_length:
            continue
        else:
            #세포분열
            if smaller_than_everything(possible_seq,cur) == True:
                possible_seq.append([cur])
            else:
                possible_seq = process(possible_seq, cur)
                
    else:#prev<cur
        if bigger_than_everything(possible_seq,cur) == True:
            #print("bigger than everything")
            possible_seq = prune(possible_seq, cur)
        else:
            possible_seq = insert(possible_seq,cur)
    #display(possible_seq)
    prev = cur
    i += 1

#display(possible_seq)
print(find_max_length(possible_seq))

