#1780 divide and conquer

def find_size(N):
    while N/3 != 1:
        sizes.append([int(N/3)])
        N = N/3
    sizes[[1]]
    return sizes

def converge(matrix):
    if len(matrix) == 1:
        n_zero = 0
        n_one = 0
        n_minus = 0
        
        if matrix[0]== -1:
            n_minus = 1
            return n_minus
        elif matrix[0] == 1:
            n_one = 1
            return n_one
        else:
            n_zero = 1
            return n_zero
        
    answer = matrix[0][0]
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j] != answer:
                return 100
    return answer

def count(matrix, sizes):
    original_matrix = matrix
    trial = converge(matrix)
    if trial != 100:
        return trial
    matrix_list = [matrix]
    n_zero = 0
    n_one = 0
    n_minus = 0
    bandwidth = len(matrix)
    while matrix_list:
        matrix = matrix.pop()
        bandwidth = int(bandwidth/3)
        n_times = len(matrix)//bandwidth
        idx = []
        for j in range(n_times):
            for k in range(n_times):
                tmp = [j*bandwidth,k*bandwidth,bandwidth]
                tmp_matrix = build(tmp,matrix)
                c = converge(tmp_matrix)
                if c! = 100:
                    if c == -1:
                        n_minus +=1
                    elif c == 0:
                        n_zero += 1
                    else:
                        n_one += 1
                else:
                    matrix_list.append(tmp_matrix)
    
                
        
        
    
N = int(input())
matrix = []
for i in range(N):          # A for loop for row entries
    a = input().split()
    a = [int(x) for x in a]
    matrix.append(a)

original_matrix = matrix
sizes = find_size(N)
count(matrix, sizes)
print(sizes)

if answer == 100:
    print("all not equal")
else:
    print(answer)
    
