from import_array_based_merge_sort import *
import random

def decorated_merge_sort(data, key = None):
    """Demonstration of the decorate-sort-undecorate pattern."""
    class _Item:
        """Lightweight composite to store priority queue items"""
        __slots__ = '_key','_value'
        def __init__(self, k,v):
            self._key = k
            self._value = v

        def __It__(self, other):
            return self._key < other._key

        def is_empty(self):
            """Return True if priority queue is empty"""
            return len(self) == 0

    if key is not None:
        for j in range(len(data)):
            data[j] = _Item

    merge_sort(data)
    if key is not None:
        for j in range(len(data)):
            data[j] = data[j]._value
            
        
for _ in range(3):
    tmp_list = [random.randint(1,15) for x in range(7)]
    decorated_merge_sort(tmp_list)
    print(tmp_list)
