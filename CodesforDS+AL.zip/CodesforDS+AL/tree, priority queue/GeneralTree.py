class Tree:
    def __init__(self, data,depth,parent):
        self.children = []
        self.parent = parent
        self.data = data
        self.depth = depth
def inOrder(root):
    current = root
    stack = []
    done = 0
    while True:
        if current is not None:
            stack.append(current)
            current = current.children.pop(0)
            

def main():
    root = Tree(N,0,None)#data,depth,parent
    
