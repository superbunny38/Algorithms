import numpy as np
bunny = [0,1]
rabbit = [0,0]
total = [0,1]

def get_bunny_rabbit_total(m):
    #m: month
    for _ in range(m-1):
        last_r = rabbit[-1]
        last_b = bunny[-1]
        bunny.append(last_r)
        rabbit.append(last_r+last_b)        
    #print(rabbit) 
    print("month: {} bunny: {} rabbit: {} total: {}".format(m,bunny[m],rabbit[m],bunny[m]+rabbit[m]))

while True:
    try:
        inp = int(input("month:"))
    except:
        break
    get_bunny_rabbit_total(inp)
