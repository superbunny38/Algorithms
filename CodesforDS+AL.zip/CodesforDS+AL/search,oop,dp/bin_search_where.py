#binary search to return the index of finding value
def bin_search(ss,key):
    low = 0
    high = len(ss)-1
    while low<=high:
        mid = (high+low)//2
        if key == ss[mid]:
            return mid
        elif key<ss[mid]:
            high = mid-1
        else:
            low = mid+1
    return None
ss = [1,2,3,4,5,6]
print(bin_search(ss,5))
