#binary search: split ordered list in half and search

#recursion
def bin_search_ox(ss,key):#찾는 값:key
    if ss != []:
        mid = len(ss)//2
        if key == ss[mid]:
            return True
        elif key<ss[mid]:
            return bin_search_ox(ss[:mid],key)
        else:
            return bin_search_ox(ss[mid+1:],key)
    else:
        return False

print(bin_search_ox([1,2,3,4,5],3))
print(bin_search_ox([1,2,3,4,5],7))

#while
def while_bin_search_ox(ss,key):
    while ss != []:
        mid = len(ss)//2
        if key == ss[mid]:
            return True
        elif key<ss[mid]:
            ss = ss[:mid]
        else:
            ss = ss[mid+1:]
    return False


print(while_bin_search_ox([1,2,3,4,5],3))
print(while_bin_search_ox([1,2,3,4,5],7))
