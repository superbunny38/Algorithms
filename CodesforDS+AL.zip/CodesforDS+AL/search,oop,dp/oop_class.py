
class Card:
    def __init__(self, suit, rank, face_up = True):
        self.suit = suit
        self.rank = rank
        self.face_up = face_up

    def __str__(self):#클래스 인스턴스 프린트하면 출력되는 결과물
        if self.face_up:
            return self.suit+"."+self.rank
        else:
            return "xxxx"+"."+"xx"

#card = Card("Spade", "7")
#print(card.face_up)

#card = Card("Spade","7",False)
#print(card.face_up)

card = Card("Spade","7")
#print(card)


#card = Card("Spade",7)#7이 str이 아니라서 오류 남

class PlayingCard:
    def __init__(self, suit, rank, face_up = True):
        self.suit = suit
        self.rank = rank
        self.face_up = face_up

    def flip(self):
        self.face_up = not self.face_up
card = PlayingCard("Spade","7")
#print(card.face_up)
card.flip()
#print(card.face_up)

class Card_with_Attributes:
    #attributes
    suits = ("Diamond", "Heart", "Spade", "Clover")
    ranks = ("A","2","3","4","5","6","7","8","9","10","J","Q","K")

    def __init__(self, suit, rank, face_up = True):
        self.suit = suit
        self.rank = rank
        self.face_up = face_up

    def flip(self):
        self.face_up = not self.face_up

print(Card_with_Attributes.suits)#calling attributes from class
CA = Card_with_Attributes("S","7")#calling attributes from instance
print(CA.suits)

class Card_encapsulation:
    __suits = ("Diamond", "Heart", "Spade", "Clover")#__:외부의 접근 차단
    __ranks = ("A","2","3","4","5","6","7","8","9","10","J","Q","K")

    def __init__(self, suit, rank, face_up = True):
        self.__suit = suit
        self.__rank = rank
        self.__face_up = face_up

    def flip(self):
        self.__face_up = not self.__face_up

    def show_suit(self):#encapsulation 공개 방법
        return self.__suit

Secret = Card_encapsulation("King","1")
try:
    print(Secret.__suit)
except Exception as e:
    print(e)
try:
    print(Secret.__suits)
except Exception as e:
    print(e)

print(Secret.show_suit())
