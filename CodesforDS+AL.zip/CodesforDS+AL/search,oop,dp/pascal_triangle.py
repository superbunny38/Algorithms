def comb_pascal(n,r):
    matrix = [[]]*(n-r+1)
    matrix[0] = [1]*(r+1)
    for i in range(1,n-r+1):
        matrix[i] = [1]
    for m in matrix:
        print(m)
comb_pascal(5,3)
