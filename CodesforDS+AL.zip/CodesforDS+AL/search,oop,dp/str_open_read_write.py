with open("input.txt.","w") as f:
    f.write("새나라의 대학생은 일찍 일어납니다\n")
    f.write("잠꾸러기 없는 나라\n")
    f.write("우리나라 좋은 나라")

with open("input.txt.","r") as f:
    for line in f:
        print(line)
print("\n\nwithout with:\n")
t = open("input.txt","r")
print(t.read())#전체를 다 읽어옴
t.close()

t = open("input.txt","r")
print("first 9 words")
print(t.read(9))
t.close()

t = open("input.txt","r")
print(t.readlines())#줄->str 모두 리스트에 저장하여 출력
t.close()

