#sequential_search: 앞에서부터 차례로 하나씩 검색
def seq_search_ox(s,key):
    if s!= []:
        if s[0] == key:
            return True
        else:
            return seq_search_ox(s[1:],key)
    else:
        return False

print(seq_search_ox([3,5,4,2],4))#find 4

print(seq_search_ox([3,5,4],6))#find 6

#반복문 기반
def for_seq_search_ox(s,key):
    for x in s:
        if x == key:
            return True
    return False


print(for_seq_search_ox([3,5,4,2],4))#find 4

print(for_seq_search_ox([3,5,4],6))#find 6
