#dp(without recursion)
def fibo(n):
    i = 1
    bunny,rabby = 1,0
    while i<n:
        i = i + 1
        bunny, rabby = rabby, bunny+rabby
    return bunny+rabby

print(fibo(5))

def fibo2(n):
    i = 1
    bunny, rabby = 1,0
    while i < n:
        i = i+1
        temp = bunny
        bunny= rabby
        rabby = temp+rabby
    return bunny+rabby

print(fibo2(5))
