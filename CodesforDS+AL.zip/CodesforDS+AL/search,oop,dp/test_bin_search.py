from bin_search_where import bin_search
import random
def test_bin_search():
    print("Binary search test!")
    db = random.sample(range(10000),1000)
    db.sort()
    for i in range(10):
        key = random.randrange(10000)
        index = bin_search(db,key)
        print(key,"found at",index)

test_bin_search()
