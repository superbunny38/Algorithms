def seq_search(s,key):
    i = 0
    for x in s:
        if x == key:
            return i#return index of finding value
        i+=1
    return None

s = [1,3,4]
print(seq_search(s,3))
