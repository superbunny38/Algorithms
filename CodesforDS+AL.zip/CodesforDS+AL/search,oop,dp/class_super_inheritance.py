class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * self.length + 2 * self.width

# Here we declare that the Square class inherits from the Rectangle class
class Square(Rectangle):
    def __init__(self, length):
        super().__init__(length, length)
        
    def show_perimeter(self):
        return self.perimeter()#함수면 괄호 붙여서 사용해야 함
square = Square(4)
print(square.area())
print(square.show_perimeter())
