sentence = "David Beckham is one of the English famous soccer playerm and is beloved"
print(sentence.find("is"))
print(sentence.find("is"))#첫번째is index 반환

idx = sentence.find("is")
print(sentence[idx:idx+len("is")])#is 출력


print("startswith:\n")
print(sentence.startswith("david"))#False: 대소문자 구분있음
print(sentence.startswith("David"))#True

print(sentence.endswith(".reyalp"))#False
print(sentence.endswith("."))#False
print(sentence.endswith("loved"))#True

print(sentence.find("a"))
print(sentence.find("a",7))
print(sentence.find("a",10,50))
