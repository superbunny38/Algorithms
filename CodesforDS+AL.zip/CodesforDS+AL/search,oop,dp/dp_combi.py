#dp_combi

def dp_combi(n,r):
    #initialize matrix with None
    matrix = [[None for _ in range(n-r+1)] for u in range(r+1)]
    for i in range(len(matrix[0])):
        matrix[0][i] = 1
    for j in range(len(matrix)):
        matrix[j][0] = 1
    row = 1
    idx = 1
    while row < len(matrix):
        while idx<len(matrix[0]):
            matrix[row][idx] = matrix[row][idx-1]+matrix[row-1][idx]
            idx += 1
        row+=1
        idx = 1
        
    #dynamic programming
    
    
    print("matrix:\n")
    for m in matrix:
        print(m)
    #print("matrix shape:{}x{}".format(len(matrix),len(matrix[0])))

    return matrix[-1][-1]

print(dp_combi(5,3))
