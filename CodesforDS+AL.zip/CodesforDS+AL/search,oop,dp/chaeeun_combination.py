def combi(n,r):
    if n<r:
        return False
    if n ==r or r == 0:
        return 1
    else:
        return combi(n-1,r)+combi(n-1,r-1)
    
while True:
    n,r = map(int,input().split())
    result = combi(n,r)
    if result == False:
        break
    print(result)
