#decorator

class Card:
    __suits = ("Diamond","Heart","Spade","Clover")
    __ranks =  ("A","2","3","4","5","6","7","8","9","10","J","Q","K")

    def __init__(self, suit, rank, face_up = True):
        self.__suit = suit
        self.__rank = rank
        self.__face_up = face_up

    def flip(self):
        self.__face_up = not self.__face_up

    def suit(self):
        return self.__suit

    def rank(self):
        return self.__rank

    def face_up(self):
        return self.__face_up
    
    @property#() 붙이지 않아야 반환됨(()있으면 오류남)
    def property_suit(self):
        return self.__suit


c = Card("King","A")
print("without bracket")
print(c.suit)
print(c.property_suit)

print("with bracket")
print(c.suit())
print(c.property_suit())#오류
    
