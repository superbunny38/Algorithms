#문제 1
#교수님 답안
def find_first(filename,key):
    infile = open(filename,"r")
    outfile = open("result.txt","w")#동시에 여러 파일 열기 가능
    text = infile.read()
    pos = text.find(key)
    if pos ==-1:
        outfile.write(key+"is not found.\n")
    else:
        outfile.write(key+"is at "+str(pos)+" \n")
    infile.close()
    outfile.close()
    print("done!")


with open("article2.txt","w") as f:
    f.write("룰루랄라 컴퓨터 유후 컴퓨터")#바로 저장하면 또 괜찮
    
find_first("article2.txt","컴퓨터")

with open("result.txt","r") as f:
    for line in f:
        print(line)




#내 답안
def find_first_ch(file_name, string):
    t = open(file_name,  'rt', encoding='UTF8')#이렇게 안 하면 무조건 오류
    text = t.read()
    idx = text.find(string)
    t.close()
    new_txt = open("result.txt","w")
    idx = str(idx)
    new_txt.write(idx)#int는 write할 수 없음. str로 변환해야 함
    new_txt.close()

#find_first("article.txt","컴퓨터")


#t = open("article.txt", 'rt', encoding='UTF8')#문서로 저장한 한국어 열
#print(t.read())
#t.close()


find_first_ch("article.txt","컴퓨터")

with open("result.txt","r") as f:
    for line in f:
        print(line)
