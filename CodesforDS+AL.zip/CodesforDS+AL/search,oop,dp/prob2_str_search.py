#교수님 코드

def find_second_prof(file_name, key):
    infile = open(file_name,"r")
    outfile = open("result0.txt","w")
    text = infile.read()
    pos = text.find(key)

    if pos == -1:
        outfile.write(key+"is not found.\n")
    else:
        outfile.write(key+"is at"+str(pos)+"the 2nd time.\n")
    outfile.close()
    infile.close()


#내코드
def find_second(file_name,string):
    to_write = open("result2.txt","w")
    to_r = open(file_name,"r")
    to_read = to_r.read()
    count = 0
    idx = to_read.find(string)
    if idx == -1:
        result = "not found"
    else:
        new_idx = to_read.find(string,idx+1,len(to_read))
        result = str(new_idx)
    
    to_write.write(result)
    to_write.close()

def find_nth(file_name,string,n):
    to_write = open("result3.txt","w")
    to_r = open(file_name,"r")
    to_read = to_r.read()
    count = 0
    idx = to_read.find(string)
    if idx == -1:
        result = "not found"
    else:
        if n == 1:
            result = idx
        else:
            for i in range(n-1):
                idx = to_read.find(string,idx+1,len(to_read))
            result = idx
        result = str(idx)
    
    to_write.write(result)
    to_write.close()    

with open("article3.txt","w") as f:
    f.write("컴퓨터 ㅇㄹ호ㅓㅏㅗㅎㄹ호ㅓㅏ 컴퓨터호ㅓㅗ호ㅓㅏ 컴퓨터ㅗㅓㅏㅣㅓㅏㅣ 컴퓨터ㅕ어냐컴퓨터")
    
print("find second 컴퓨터 in article2.txt")
find_second("article2.txt","컴퓨터")
find_second_prof("article2.txt","컴퓨터")

with open("article2.txt","r") as f:
    for line in f:
        print(line)
with open("result2.txt") as f:
    save = 0
    for line in f:
        print(line)
        save = line

with open("result0.txt") as f:
    save = 0
    for line in f:
        print(line)
        save = line

print("검산:")
with open("article2.txt","r") as f:
    for line in f:
        print(save)
        print(line[int(save):int(save)+len("컴퓨터")])

n = int(input("input n:"))
find_nth("article3.txt","컴퓨터",n)
print("original article")
with open ("article3.txt","r") as f:
    for line in f:
        print(line)
        
with open("result3.txt") as f:
    save2 = 0
    for line in f:
        print(line)
        save2 = int(line)

print("검산")
with open("article3.txt","r") as f:
    for line in f:
        print(save2)
        print(line[int(save2):int(save2)+len("컴퓨터")])
