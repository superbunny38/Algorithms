class Rectangle:
    """
    defines something something
    possible to print second line
    """
    """another doc"""#얘는 __doc__으로 출력안됨
    count = 2#클래스 변수
    
    def __init__(self, width, height):
        self.width = width
        self.height = height
        Rectangle.count += 1

    #인스턴스 메서드
    def calcArea(self):
        area = self.width * self.height
        return area

    #정적 메서드: 인스턴스가 생성되지 않았어도 사용 가능
    @staticmethod
    def isSquare(rectWidth, rectHeight):
        return rectWidth == rectHeight
    def Hey(self):
        print("hey~")

    @staticmethod
    def heyheyhey():
        print("heyheyhey~")

    #클래스 메서드:
    @classmethod
    def printCount(cls):
        print(cls.count)
try:
    print(Rectangle.Hey())
except Exception as e:
    print(e)

print(Rectangle.printCount())#이렇게 하면 None이 반환됨

print(Rectangle.heyheyhey())

print(Rectangle.isSquare(5,5))
rect1 = Rectangle(5,5)
rect1.printCount()
print(rect1.__doc__)
