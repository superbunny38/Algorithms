import random
db = random.sample(range(10000),1000)#1000개 생성
print("len(db):",len(db))
key = db[109]
print(db.index(key))#key가 value인 값의 index
