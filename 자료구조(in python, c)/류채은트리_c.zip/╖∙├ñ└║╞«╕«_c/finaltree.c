#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>
#pragma warning(disable: 4996)


typedef char element;
typedef struct TreeNode {
	element data;
	struct TreeNode* next, * child, * parent;
}TreeNode;



//���ο� ��� ����
TreeNode* new_node(TreeNode* parent, element item) {
	TreeNode* temp = (TreeNode*)malloc(sizeof(TreeNode));
	temp->data = item;
	temp->next = temp->child = NULL;
	temp->parent = parent;
	return temp;
}



//search

TreeNode* search(TreeNode* root, element data) {
	TreeNode* node = root;

	while (node) {
		//printf("---\n");
		//printf("node: %c\n ", node->data);
		if (node->data == data) {
			return node;
		}
		if (node->parent) {
			//printf("parent: %c\n", node->parent->data);
		}
		else {
			//printf("NULL parent\n");
		}
		if (node->child) {
			TreeNode* child = node->child;
			//printf("child : ");
			while (child) {

				//printf("%c ", child->data);
				child = child->next;
			}
			//printf("\n");
		}
		else {
			//printf("NULL child\n");
		}
		if (node->child) {
			//printf("|");
			node = node->child;
		}
		else {
			if (node->next) {
				node = node->next;
			}
			else {
				node = node->parent->next;
			}

		}
	}
	printf("Error!\n");
	return 0;
}


TreeNode* insert_node(TreeNode* root, TreeNode* parent, element data) {
	if (root == NULL) {//
		TreeNode* new = new_node(parent, data);
		root = new;
		return root;
	}
	else {

		if (parent->child == NULL) {//no child for parent
			TreeNode* new = new_node(parent, data);
			parent->child = new;
			new->parent->next = parent->next;
			return root;
		}
		else {//parent has a child
			TreeNode* tmp = parent->child;
			while (tmp->next) {
				tmp = tmp->next;
			}
			tmp->next = new_node(parent, data);
			return root;
		}

	}
}


//����
#define SIZE 100
int top = -1;
TreeNode* stack[SIZE];

void push(TreeNode* p) {
	if (top < SIZE - 1) {
		stack[++top] = p;
	}
}

TreeNode* pop() {
	TreeNode* p = NULL;
	if (top >= 0) {
		p = stack[top--];

	}
	return p;
}

TreeNode* peek() {
	TreeNode* p = NULL;
	if (top >= 0) {
		p = stack[top];
	}
	return p;
}

//���� ����

/*

TreeNode* rprint(TreeNode* root) {
	if (root != NULL) {
		return root;
		rprint(root->child);
		rprint(root->next);
	}
}

void print(TreeNode* root) {
	TreeNode* node = rprint(root);

		if (node->data == node->parent->child->data) {
			printf('(');
		}
		printf(" %c, ", node->data);
		if (!node->next) {
			printf(')');
		}

}
*/


void print(TreeNode* root) {
	if (root != NULL) {
		printf("%c", root->data);
		if (root->child) {
			printf("(");
		}
		else if (!root->next) {
			if (root->parent) {
				printf(")");
			}

		}
		else {
			printf(",");
		}
		print(root->child);


		print(root->next);


	}
}

void get_sibling(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	if (node == 0) {
		printf("searching error!");
		return;
	}
	//printf("data�� ã��\n", node->data);
	TreeNode* tmp = node->parent->child;
	while (tmp) {
		if (tmp->data != data) {
			printf("%c ", tmp->data);
		}

		tmp = tmp->next;
	}
}

TreeNode* get_parent(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	if (node->parent) {
		return node->parent;
	}
	else {
		return 0;
	}
}

void get_child(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	TreeNode* child = node->child;
	while (child) {
		printf("%c ", child->data);
		child = child->next;
	}
}


int MAX(int a, int b) {
	if (a > b) {
		return a;
	}
	else {
		return b;
	}
}



int level_of_node(TreeNode* root, element data) {
	int ln = 0;
	TreeNode* node = search(root, data);
	//printf("node : %c\n",node->data);
	TreeNode* parent = node->parent;
	//printf("parent : %c\n", node->parent->data);
	//parent ���� 1�� -> ln�� 2
	if (node->data == root->data) {
		return ln;
	}
	while (parent) {
		//printf("parent->data : %c || root->data: %c\n", parent->data, root->data);
		if (parent->data == root->data) {
			ln++;
			return ln;
		}
		else {
			ln++;
			parent = parent->parent;
		}
	}
	return NULL;

}

int level_of_tree(TreeNode* root) {
	TreeNode* node = root;
	int tmp = 0;
	int result = 0;
	while (node) {
		//node���� child���� Ȯ�� ��
		//������ next���
		//������ child���
		//			child ��� �� child next ���
		//							child next ������ child->parent->next
		while (node) {
			//printf("---\n");
			//printf("node: %c\n ", node->data);
			tmp = level_of_node(root, node->data);
			result = MAX(result, tmp);
			if (node->parent) {
				//printf("parent: %c\n", node->parent->data);
			}
			else {
				//printf("NULL parent\n");
			}
			if (node->child) {
				TreeNode* child = node->child;
				//printf("child : ");
				while (child) {

					//printf("%c ", child->data);
					child = child->next;
				}
				//printf("\n");
			}
			else {
				//printf("NULL child\n");
			}
			if (node->child) {
				//printf("|");
				node = node->child;
			}
			else {
				if (node->next) {
					node = node->next;
				}
				else {
					node = node->parent->next;
				}

			}
		}
	}//while
	return result;
}


TreeNode* delete_node(TreeNode* root, element data) {
	TreeNode* removed = search(root, data);
	//�ܸ� ��尡 �ƴ� ���
	if (removed->child) {
		printf("Error!\n");
		return root;
	}
	//�ܸ� ����� ���
	else {
		//   prev, node, next
		TreeNode* prev = removed->parent->child;
		TreeNode* next = removed->next;
		if (prev->data == data) {
			//   prev���� ��� parent->child �� next�� ����
			removed->parent->child = next;
			free(removed);
			return root;
		}
		else {
			//   prev ���� �� prev->next = next
			while (prev->next) {
				if (prev->next->data == data) {
					break;
				}
				prev = prev->next;
			}
			prev->next = next;
			free(removed);
			return root;
		}

	}

}

void get_ancestors(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	//printf("node : %c\n",node->data);
	TreeNode* parent = node->parent;
	//printf("parent : %c\n", node->parent->data);
	//parent ���� 1�� -> ln�� 2
	if (node->data == root->data) {
		printf("NONE\n root �Դϴ�\n");
	}
	while (parent) {
		printf("%c ", parent->data);
		//printf("parent->data : %c || root->data: %c\n", parent->data, root->data);
		if (parent->data == root->data) {
			//ln++;
			//printf("%c ",parent->data);
			break;
		}
		else {
			//ln++;
			parent = parent->parent;
		}
	}

}

void get_descendants(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	while (node) {
		//node���� child���� Ȯ�� ��
		//������ next���
		//������ child���
		//			child ��� �� child next ���
		//							child next ������ child->parent->next
		while (node) {
			//printf("---\n");
			//printf("node: %c\n ", node->data);
			if (node->parent) {
				//printf("parent: %c\n", node->parent->data);
			}
			else {
				//printf("NULL parent\n");
			}
			if (node->child) {
				TreeNode* child = node->child;
				//printf("child : ");
				while (child) {

					printf("%c ", child->data);
					child = child->next;
				}
				//printf("\n");
			}
			else {
				//printf("NULL child\n");
			}
			if (node->child) {
				//printf("|");
				node = node->child;
			}
			else {
				if (node->next) {
					node = node->next;
				}
				else {
					node = node->parent->next;
				}

			}
		}
	}
}


int degree_of_node(TreeNode* root, element data) {
	TreeNode* node = search(root, data);
	int degree = 0;
	TreeNode* child = node->child;
	while (child) {
		degree++;
		child = child->next;
	}
	return degree;
}

int degree_of_tree(TreeNode* root) {
	TreeNode* node = root;
	int tmp = 0;
	int result = 0;
	while (node) {
		//node���� child���� Ȯ�� ��
		//������ next���
		//������ child���
		//			child ��� �� child next ���
		//							child next ������ child->parent->next
		while (node) {
			//printf("---\n");
			//printf("node: %c\n ", node->data);
			tmp = degree_of_node(root, node->data);
			result = MAX(result, tmp);
			if (node->parent) {
				//printf("parent: %c\n", node->parent->data);
			}
			else {
				//printf("NULL parent\n");
			}
			if (node->child) {
				TreeNode* child = node->child;
				//printf("child : ");
				while (child) {

					//printf("%c ", child->data);
					child = child->next;
				}
				//printf("\n");
			}
			else {
				//printf("NULL child\n");
			}
			if (node->child) {
				//printf("|");
				node = node->child;
			}
			else {
				if (node->next) {
					node = node->next;
				}
				else {
					node = node->parent->next;
				}

			}
		}
	}//while
	return result;
}

/*
int degree_of_tree(TreeNode* root) {
	TreeNode* node = root;
	int tmp = 0;
	int result = 0;
	while (node) {
		while (node) {
			tmp = degree_of_node(root, node->data);
			result = MAX(result, tmp);
			if (node->parent) {
			}
			else {
			}
			if (node->child) {
				TreeNode* child = node->child;

				while (child) {

					child = child->next;
				}

			}

			if (node->child) {

				node = node->child;
			}
			else {
				if (node->next) {
					node = node->next;
				}
				else {
					node = node->parent->next;
				}

			}
		}
	}//while
	return result;
}

*/

int count_node(TreeNode* root) {
	int count = 0;
	if (root != NULL) {
		count = 1 + count_node(root->next) + count_node(root->child);
	}
	return count;
}

void insert_sibling(TreeNode* root, element sibling, element data) {
	TreeNode* n_sibling = search(root, sibling);
	TreeNode* new = new_node(n_sibling->parent, data);
	while (n_sibling->next) {
		n_sibling = n_sibling->next;
	}
	n_sibling->next = new;
}

int get_leaf_count(TreeNode* root) {
	TreeNode* node = root;
	int tmp = 0;
	int result = 0;
	while (node) {
		//node���� child���� Ȯ�� ��
		//������ next���
		//������ child���
		//			child ��� �� child next ���
		//							child next ������ child->parent->next
		while (node) {
			//printf("---\n");
			//printf("node: %c\n ", node->data);
			if (!node->child) {
				result++;
			}
			if (node->parent) {
				//printf("parent: %c\n", node->parent->data);
			}
			else {
				//printf("NULL parent\n");
			}
			if (node->child) {
				TreeNode* child = node->child;
				//printf("child : ");
				while (child) {

					//printf("%c ", child->data);
					child = child->next;
				}
				//printf("\n");
			}
			else {
				//printf("NULL child\n");
			}
			if (node->child) {
				//printf("|");
				node = node->child;
			}
			else {
				if (node->next) {
					node = node->next;
				}
				else {
					node = node->parent->next;
				}

			}
		}
	}//while
	return result;
}

void clear(TreeNode* root) {
	if (root == NULL) return;
	clear(root->child);
	clear(root->next);
	root->data = NULL;
}

void deletegongbaek(char* str) {
	char* tmp;
	tmp = str;
	while (strchr(str, ' ') != '\0') { // poly1�� ���� ���ڰ� ���� ��
		tmp = strchr(str, ' '); // ���鹮�ڰ� ��ġ�� ���� ���� ����
		*tmp = '\0';
		strcat(tmp, tmp + 1); // 
	}
}//deletegongbaek






int main(void) {

	TreeNode* root = NULL;
	TreeNode* tmp = NULL;
	TreeNode* new_root = NULL;

	char input[30];
	char ch, data, sibling;
	int n;
	printf("*J����: J(new_root)�� �Է����ּ���!\n");

	while (1) {

		fgets(input, sizeof(input), stdin);
		deletegongbaek(input);
		int len = strlen(input);

		for (int i = 0; i < len; i++) {

			ch = input[i];
			switch (ch) {
			case '+':
				if (input[i + 1] == '^') {//root����
					i += 2;
					root = new_node(NULL, input[i]);
					break;
				}
				else {
					i += 1;
					tmp = search(root, input[i]);
					if (tmp == NULL) {
						break;
					}
					i += 1;
					while (input[i]) {
						if (65 <= input[i] && input[i] <= 90) {
							root = insert_node(root, tmp, input[i]);
						}//if
						i++;
					}
					print(root);
					printf("\n");
					break;
				}
			case 'S'://get_sibling(my_tree, node)
				i += 2;
				data = input[i];
				get_sibling(root, data);
				break;

			case 'T'://print(my_tree)
				print(root);
				break;

			case 'P'://get_parent(my_tree, node)
				i += 2;
				data = input[i];
				tmp = get_parent(root, data);
				printf("%c", tmp->data);
				break;

			case 'C'://get_child(my_tree, node)
				i += 2;
				data = input[i];
				get_child(root, input[i]);
				break;

			case 'L':
				if (input[i + 1] == '(') {//level_of_node(my_tree,node)
					i += 2;
					data = input[i];
					n = level_of_node(root, data);
					printf("%d", n);
					break;
				}
				else {//level_of_tree(my_tree)
					n = level_of_tree(root);
					printf("%d", n);
					break;
				}

			case '-'://delete_node(my_tree,node)
				i++;
				data = input[i];
				delete_node(root, data);
				break;

			case 'A'://get_ancestors(my_tree,data)
				i += 2;
				data = input[i];
				get_ancestors(root, data);
				break;

			case 'D':
				i += 2;
				data = input[i];
				get_descendants(root, data);
				break;

			case 'G':
				if (input[i + 1] == '(') {//degree_of_node(my_tree,node)
					i += 2;
					data = input[i];
					n = degree_of_node(root, data);
					printf("%d", n);
					break;
				}
				else {//degree_of_tree(my_tree)
					if (i == 0) {
						n = degree_of_tree(root);
						printf("%d", n);
					}

					break;
				}

			case '#'://count_node
				n = count_node(root);
				printf("%d", n);
				break;

			case '='://insert_sibling(my_tree,node,s_list)
				if (input[i + 1] == '+') {
					i += 2;
					sibling = input[i];
					i++;
					while (input[i]) {
						if (65 <= input[i] && input[i] <= 90) {
							data = input[i];
							insert_sibling(root, sibling, data);
						}
						i++;
					}//while
				}
				break;

			case 'J'://join_trees(new_root, tree1, tree2)
				printf("tree2�� &���� ����ȭ�߽��ϴ�..��...�Ф�\n");
				i += 2;
				new_root = new_node(NULL, input[i]);
				root->parent = new_root;
				new_root->child = root;
				new_root->child->next = new_node(new_root, '&');
				printf("print joined trees:\n");
				print(new_root);
				break;

			case 'K'://clear(my_tree)
				clear(root);
				break;

			case '@'://�߰� ADT: �ܸ���� ���� ���ϱ� get_leaf_count(my_tree)
				n = get_leaf_count(root);
				printf("%d", n);
				break;


			}//switch
			if (i == len - 1) {
				printf("\n");
			}
		}

	}
	system("pause");
	return 0;
}