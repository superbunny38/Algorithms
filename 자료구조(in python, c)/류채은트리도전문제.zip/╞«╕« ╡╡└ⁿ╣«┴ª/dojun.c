#pragma warning(disable: 4996)
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>





typedef struct TreeNode {
	int data;
	struct TreeNode* next, * child, * parent;
}TreeNode;



//���ο� ��� ����
TreeNode* new_node(TreeNode* parent, int item) {
	TreeNode* temp = (TreeNode*)malloc(sizeof(TreeNode));
	temp->data = item;
	temp->next = temp->child = NULL;
	temp->parent = parent;
	return temp;
}


TreeNode* insert_node(TreeNode* root, TreeNode* parent, int data) {
	if (root == NULL) {//
		TreeNode* new = new_node(parent, data);
		root = new;
		return root;
	}
	else {

		if (parent->child == NULL) {//no child for parent
			TreeNode* new = new_node(parent, data);
			parent->child = new;
			new->parent->next = parent->next;
			return root;
		}
		else {//parent has a child
			TreeNode* tmp = parent->child;
			while (tmp->next) {
				tmp = tmp->next;
			}
			tmp->next = new_node(parent, data);
			return root;
		}

	}
}


//===���� ť �ڵ�
#define MAX_QUEUE_SIZE 100
typedef TreeNode* element;

typedef struct {
	element data[MAX_QUEUE_SIZE];
	int front, rear;
}QueueType;

void error(char* message) {
	fprintf(stderr, "%s\n", message);
	exit(1);
}

void init_queue(QueueType* q) {
	q->front = q->rear = 0;
}

int is_empty(QueueType* q) {
	return (q->front == q->rear);
}

int is_full(QueueType* q) {
	return ((q->rear + 1) % MAX_QUEUE_SIZE == q->front);
}

void enqueue(QueueType* q, element item) {
	if (is_full(q)) {
		error("ť�� ��ȭ�����Դϴ�");
	}
	q->rear = (q->rear + 1) % MAX_QUEUE_SIZE;
	q->data[q->rear] = item;
}

element dequeue(QueueType* q) {
	if (is_empty(q)) {
		error("ť�� ��������Դϴ�");

	}
	q->front = (q->front + 1) % MAX_QUEUE_SIZE;
	return q->data[q->front];
}



void deletegongbaek(char* str) {
	char* tmp;
	tmp = str;
	while (strchr(str, ' ') != '\0') { // poly1�� ���� ���ڰ� ���� ��
		tmp = strchr(str, ' '); // ���鹮�ڰ� ��ġ�� ���� ���� ����
		*tmp = '\0';
		strcat(tmp, tmp + 1); // 
	}
}//deletegongbaek

TreeNode* search(TreeNode* root, int data) {
	TreeNode* node = root;

	while (node) {
		//printf("---\n");
		//printf("node: %c\n ", node->data);
		if (node->data == data) {
			return node;
		}
		if (node->parent) {
			//printf("parent: %c\n", node->parent->data);
		}
		else {
			//printf("NULL parent\n");
		}
		if (node->child) {
			TreeNode* child = node->child;
			//printf("child : ");
			while (child) {

				//printf("%c ", child->data);
				child = child->next;
			}
			//printf("\n");
		}
		else {
			//printf("NULL child\n");
		}
		if (node->child) {
			//printf("|");
			node = node->child;
		}
		else {
			if (node->next) {
				node = node->next;
			}
			else {
				node = node->parent->next;
			}

		}
	}
	printf("Error!\n");
	return 0;
}



void get_ancestors(TreeNode* root, int data) {
	TreeNode* node = search(root, data);
	//printf("node : %c\n",node->data);
	TreeNode* parent = node->parent;
	//printf("parent : %c\n", node->parent->data);
	//parent ���� 1�� -> ln�� 2
	if (node->data == root->data) {
		printf("NONE\n root �Դϴ�\n");
	}
	while (parent) {
		printf("%d ", parent->data);
		//printf("parent->data : %c || root->data: %c\n", parent->data, root->data);
		if (parent->data == root->data) {
			//ln++;
			//printf("%c ",parent->data);
			break;
		}
		else {
			//ln++;
			parent = parent->parent;
		}
	}

}

void find_path(TreeNode* root, int data) {
	TreeNode* node = search(root, data);
	TreeNode* parent = node->parent;
	if (node->data == data) {
		printf("found node!\n");
	}
	int sum = node->data;
	int value;
	printf("%d + ", node->data);
	while (parent) {
		value = parent->data;
		if (parent->parent) {
			printf("%d + ", value);
		}
		else {
			printf("%d = ", value);
		}
		sum = sum + value;
		parent = parent->parent;
	}
	
	printf("%d", sum);
	printf("\n\n>>the sum of paths: %d", sum);
}


int main(void) {
	TreeNode* root = NULL;
	TreeNode* tmp = NULL;
	TreeNode* node = NULL;

	QueueType q;
	init_queue(&q);
	int data, count;
	
	char answer;
	

	printf("insert root: ");
	scanf("%d", &data);
	enqueue(&q, data);
	root = new_node(NULL, data);
	while (1) {
		if (!is_empty(&q)) {
			
			data = dequeue(&q);
			printf("%d has children?(Y/N): ",data);
			scanf("%s", &answer);
		}
		else {
			break;
		}
AA:		if (answer == 'Y') {
			tmp = search(root, data);
			printf("number of children: ");
			scanf("%d", &count);
			printf("input %d's children: ",data);
			for (int i = 0; i < count; i++) {
				scanf("%d", &data);
				enqueue(&q, data);
				root = insert_node(root, tmp, data);
			}//for

		}//if
		else if (answer == 'N') {
	
		}
		else {
			//dequeue(&answer_q);
			printf("invalid answer!\n");
			goto AA;
		}
		
		
	}
	printf("\n=============\n");
	printf("<finding path program>\n");
	printf("input the value that you want to find path about: ");
	scanf("%d", &data);
	find_path(root, data);

	system("pause");

	return 0;
}